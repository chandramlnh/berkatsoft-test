        <script src="<?php echo e(asset('front/js/jquery.min.js')); ?>"></script> 
        <script src="<?php echo e(asset('front/js/bootstrap.min.js')); ?>"></script> 
        <script src="<?php echo e(asset('front/js/swiper.min.js')); ?>"></script> 
        <script src="<?php echo e(asset('front/js/fancybox.min.js')); ?>"></script> 
        <script src="<?php echo e(asset('front/js/scripts.js')); ?>"></script>
    </body>
</html><?php /**PATH F:\Berkatsoft\resources\views/layout/foot.blade.php ENDPATH**/ ?>