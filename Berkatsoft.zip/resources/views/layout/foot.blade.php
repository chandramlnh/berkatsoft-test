        <script src="{{ asset('front/js/jquery.min.js') }}"></script> 
        <script src="{{ asset('front/js/bootstrap.min.js') }}"></script> 
        <script src="{{ asset('front/js/swiper.min.js') }}"></script> 
        <script src="{{ asset('front/js/fancybox.min.js') }}"></script> 
        <script src="{{ asset('front/js/scripts.js') }}"></script>
    </body>
</html>