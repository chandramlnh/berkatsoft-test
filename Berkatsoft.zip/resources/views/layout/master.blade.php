@include('layout.head')
@include('layout.menu')
@yield('content')
@include('layout.foot')